import { ProdutosClientePipe } from './produtos-cliente.pipe';

describe('ProdutosClientePipe', () => {
  it('create an instance', () => {
    const pipe = new ProdutosClientePipe();
    expect(pipe).toBeTruthy();
  });
});
