import { SubListaPipe } from './sub-lista.pipe';

describe('SubListaPipe', () => {
  it('create an instance', () => {
    const pipe = new SubListaPipe();
    expect(pipe).toBeTruthy();
  });
});
