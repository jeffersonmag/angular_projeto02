import { CategoriaPipe } from './categoria.pipe';

describe('CategoriaPipe', () => {
  it('create an instance', () => {
    const pipe = new CategoriaPipe();
    expect(pipe).toBeTruthy();
  });
});
