import { DescontoPipe } from './desconto.pipe';

describe('DescontoPipe', () => {
  it('create an instance', () => {
    const pipe = new DescontoPipe();
    expect(pipe).toBeTruthy();
  });
});
