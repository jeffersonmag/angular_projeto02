import { SimboloPipe } from './simbolo.pipe';

describe('SimboloPipe', () => {
  it('create an instance', () => {
    const pipe = new SimboloPipe();
    expect(pipe).toBeTruthy();
  });
});
