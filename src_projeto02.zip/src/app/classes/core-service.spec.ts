import { CoreService } from './core-service';

describe('CoreService', () => {
  it('should create an instance', () => {
    expect(new CoreService()).toBeTruthy();
  });
});
